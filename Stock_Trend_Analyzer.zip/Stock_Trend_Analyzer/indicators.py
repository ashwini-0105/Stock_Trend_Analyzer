import pandas as pd
import talib
import numpy as np

def add_indicators(df):
    df["SMA20"] = df["Close"].rolling(20).mean()
    df["SMA50"] = df["Close"].rolling(50).mean()
    close_array = np.array(df["Close"], dtype=np.float64).flatten()
    df["RSI"] = talib.RSI(close_array, timeperiod=14)
    return df
