import matplotlib.pyplot as plt

def plot_chart(df, stock):
    plt.figure(figsize=(14, 7))
    plt.plot(df["Close"], label="Close Price")
    plt.plot(df["SMA20"], label="SMA 20")
    plt.plot(df["SMA50"], label="SMA 50")

    plt.title(f"{stock} Stock Trend Analysis")
    plt.xlabel("Date")
    plt.ylabel("Price")
    plt.legend()
    plt.grid(True)
    plt.show()
