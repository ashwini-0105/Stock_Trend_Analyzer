def apply_strategy(df):
    signals = []

    for i in range(len(df)):
        if df["SMA20"].iloc[i] > df["SMA50"].iloc[i] and df["RSI"].iloc[i] < 70:
            signals.append("BUY")

        elif df["SMA20"].iloc[i] < df["SMA50"].iloc[i] and df["RSI"].iloc[i] > 30:
            signals.append("SELL")

        else:
            signals.append("HOLD")

    df["Signal"] = signals
    return df
