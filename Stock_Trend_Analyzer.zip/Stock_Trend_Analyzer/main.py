from data_fetcher import fetch_data
from indicators import add_indicators
from strategy import apply_strategy
from visualize import plot_chart

def predict_next(df):
    last_signal = df["Signal"].iloc[-1]

    if last_signal == "BUY":
        return "Stock likely to move UP (Bullish)"
    elif last_signal == "SELL":
        return "Stock likely to move DOWN (Bearish)"
    else:
        return "Trend neutral / sideways"

if __name__ == "__main__":
    stock = input("Enter Stock Symbol (e.g., TCS.NS, AAPL): ")

    df = fetch_data(stock)
    df = add_indicators(df)
    df = apply_strategy(df)

    print("\nLast 5 Signals:")
    print(df[["Close", "SMA20", "SMA50", "RSI", "Signal"]].tail())

    trend = predict_next(df)
    print("\nPrediction for next day:", trend)

    plot_chart(df, stock)
