import yfinance as yf
import pandas as pd

def fetch_data(stock, period="2y"):
    data = yf.download(stock, period=period)
    data.dropna(inplace=True)
    return data
